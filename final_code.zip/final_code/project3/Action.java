public abstract class Action{
   protected abstract void executeAction(EventScheduler scheduler);
}